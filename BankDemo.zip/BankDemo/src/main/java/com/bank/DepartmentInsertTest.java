package com.bank;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DepartmentInsertTest {
	public static void main(String[] args) {
		
		//load the driver - Dm.registerDriver
		//get the connection Dm.getConnection
		//make a statement conn.createStatement
		//execute the statement  st.executeQuery("insert into dept20 values (?,?,?)
		//process the result if any ? managment of ? with index
		
		Configuration config = new Configuration();
		System.out.println("=> Configuration created..."+config);
		
		SessionFactory factory = config.configure("hibernate.cfg.xml").buildSessionFactory();
		System.out.println("=> Factory created : "+factory);
		
		Session mySession = factory.getCurrentSession();
		System.out.println("=> Got the session : "+mySession);
		
		Transaction myTransaction = mySession.beginTransaction();
		System.out.println("=> Started the transaction : "+myTransaction);
		
			//Department myDeptObj1 = new Department(10,"IT","New York");
			//Department myDeptObj2 = new Department(20,"Research","New Mumbai");
			Department myDeptObj3 = new Department(30,"Sales","New Zealand");
			Department myDeptObj4 = new Department(40,"Operations","New Panvel");
			
			System.out.println("=> dept obj is filled up...");
			
			System.out.println("=> Trying to persist the object...");
			//mySession.save(myDeptObj1);
			//mySession.save(myDeptObj2);
			mySession.save(myDeptObj3);
			mySession.save(myDeptObj4);
			
			System.out.println("=> Objects persisted to the DB...");
			System.out.println();
			
			
		myTransaction.commit();
		System.out.println("=> Transaction committed...");
		
		factory.close();
		System.out.println("=> Session factory closed....");

		
		
	}
}
