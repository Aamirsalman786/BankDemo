package com.bank;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DepartmentDeleteTest {
	public static void main(String[] args) {
		
		//load the driver - Dm.registerDriver
		//get the connection Dm.getConnection
		//make a statement conn.createStatement
		//execute the statement  st.executeQuery("insert into dept20 values (?,?,?)
		//process the result if any ? managment of ? with index
		
		Configuration config = new Configuration();
		System.out.println("=> Configuration created..."+config);
		
		SessionFactory factory = config.configure("hibernate.cfg.xml").buildSessionFactory();
		System.out.println("=> Factory created : "+factory);
		
		Session mySession = factory.getCurrentSession();
		System.out.println("=> Got the session : "+mySession);
		
		Transaction myTransaction = mySession.beginTransaction();
		System.out.println("=> Started the transaction : "+myTransaction);
		
		Department deptRef1 = new Department(); //transient
		deptRef1.setDepartmentNumber(30); //simply primary key
		System.out.println("trying to delete 30");
		mySession.delete(deptRef1);
		//above deptRef1 just has 30 , and no need of any other details
		
		//below is not transient, its persisted object from the db
		Department deptRef2 = mySession.get(Department.class, 40);
		System.out.println("trying to delete 40");
		//deptRef2 has entire detail of 40, ie its name and location
		mySession.delete(deptRef2);
			
			
		myTransaction.commit();
		System.out.println("=> Transaction committed...");
		
		factory.close();
		System.out.println("=> Session factory closed....");

	/*	try
		{
			//1
		}
		catch() {
			
		}
		
		try
		{
			//2
			//3
		}
		catch() {
			
		}
		
		try
		{
			//4
			//5
		}
		catch() {
			
		}
		
		//6 ur code
		//7 ur code
		
		try
		{
			//8
			//9
		}
		catch() {
			
		}
		
		//10 ur code
		//11 ur code
		 
	*/
	}
}
