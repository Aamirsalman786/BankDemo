package com.bank;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DepartmentSelectTest {
	public static void main(String[] args) {
		
		//load the driver - Dm.registerDriver
		//get the connection Dm.getConnection
		//make a statement conn.createStatement
		//execute the statement  st.executeQuery("insert into dept20 values (?,?,?)
		//process the result if any ? managment of ? with index
		
		Configuration config = new Configuration();
		System.out.println("=> Configuration created..."+config);
		
		SessionFactory factory = config.configure("hibernate.cfg.xml").buildSessionFactory();
		System.out.println("=> Factory created : "+factory);
		
		Session mySession = factory.getCurrentSession();
		System.out.println("=> Got the session : "+mySession);
		
		Transaction myTransaction = mySession.beginTransaction();
		System.out.println("=> Started the transaction : "+myTransaction);
		
			Department myDeptObj = null; //not an object
			//hence no question of transient 
			
			System.out.println("=> null dept reference : "+myDeptObj);
			System.out.println("=> Trying to find the object...");
			//angular form input -> angular service -> angular http call
			// -> http call -> rest api -> dao- > hibernate app -> database
			int number = 0;
			do
			{
				System.out.println("--- SEARCH DEPT MENU ---");
				System.out.println("Enter dept number to seaerch : ");
				Scanner scan = new Scanner(System.in);
				number = scan.nextInt();
				myDeptObj = mySession.get(Department.class, number);
				if(myDeptObj!=null) {
					System.out.println("=> dept found ..."+myDeptObj);
					System.out.println("deptno : "+myDeptObj.getDepartmentNumber());
					System.out.println("dname  : "+myDeptObj.getDepartmentName());
					System.out.println("loc    : "+myDeptObj.getDeparmentLocation());
				}
				else {
					System.out.println("Dept "+number+" NOT found");
				}
		
				System.out.println("-----------------");
				
			} while(number!=0);
				
			
			// |
			// this is an attached object -> means corresponding row is there 
			
			
		myTransaction.commit();
		System.out.println("=> Transaction committed...");
		
		factory.close();
		System.out.println("=> Session factory closed....");

		
		
	}
}
