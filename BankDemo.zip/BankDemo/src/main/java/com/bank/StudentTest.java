package com.bank;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentTest {
	public static void main(String[] args) {
		
		//load the driver - Dm.registerDriver
		//get the connection Dm.getConnection
		//make a statement conn.createStatement
		//execute the statement  st.executeQuery("insert into dept20 values (?,?,?)
		//process the result if any ? managment of ? with index
		
		Configuration config = new Configuration();
		System.out.println("=> Configuration created..."+config);
		
		SessionFactory factory = config.configure("hibernate.cfg.xml").buildSessionFactory();
		System.out.println("=> Factory created : "+factory);
		
		Session mySession = factory.getCurrentSession();
		System.out.println("=> Got the session : "+mySession);
		
		Transaction myTransaction = mySession.beginTransaction();
		System.out.println("=> Started the transaction : "+myTransaction);
		
			Student s1 = new Student();//transient
			System.out.println("=> Empty student object created : "+s1);
			s1.setRollNumber(9);
			s1.setName("Ashok");
			s1.setMarks(89.6f);
			
			Student s2 = new Student();//transient
			s2.setRollNumber(10);
			s2.setName("Jagdish");
			s2.setMarks(99.6f);
			
			Student s3 = new Student();//transient
			s3.setRollNumber(11);
			s3.setName("Aamir");
			s3.setMarks(95.3f);
			
			
			
			System.out.println("=> s1,s2,s3 objs filled up...");
			
			System.out.println("=> Trying to persist the objects...");
			mySession.save(s1);
			mySession.save(s2);
			mySession.save(s3);
			//now if all above three lines are
			//successfull, they are persistent
			//no longer as transient

			
			
			System.out.println("=> Objects persisted to the DB...");
			System.out.println();
			
			
		myTransaction.commit();
		System.out.println("=> Transaction committed...");
		
		factory.close();
		//they are detached now - no longer
		//connected to the db
		
		
		System.out.println("=> Session factory closed....");

		
		
	}
}
