package com.bank.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.bank.Department;

import junit.framework.Assert;

public class DepartmentDAOTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DepartmentDAO deptDao = new DepartmentDAOImpl();
		Department deptObj = new Department(40,"TEST","Pune");
		deptDao.insertDepartment(deptObj);
	}
	
	@Test
	public void testInsert() {
		DepartmentDAO deptDao = new DepartmentDAOImpl();
		Department deptObj = new Department(50,"Quality","Nagpur");
		deptDao.insertDepartment(deptObj);
	}

	@Test
	public void testSelect() {
		DepartmentDAO deptDao = new DepartmentDAOImpl();
		System.out.println("Line2:");
		Department deptObj = deptDao.getDepartment(90);
		assertNotNull(deptObj);
		System.out.println("Line5: dept : "+deptObj);
		
		//if(deptObj!=null)
//			System.out.println("Line5: dept : "+deptObj);
	//	else 
		//	throw new RuntimeException("Department not found");
	}
	
	@Test
	public void testSelectAll() {
		DepartmentDAO deptDao = new DepartmentDAOImpl();
		//2
		//3
		
		System.out.println("Line2:");
		List<Department> deptList = deptDao.getDepartments();
		assertTrue(deptList.size()>0);
		System.out.println("Line5: dept : "+deptList.size());
		for (Department dept : deptList) {
			System.out.println("Dept : "+dept);
		}
	}
	//the role is different
	//you as a developer /chef as developed it
	
	//tester is going to test it 
	
	
	
	@Test
	public void testFundTransfer() {
		//AccountDAO accDao = ..;
		//PayeeDAO payeeDao = ...
		//Account acc = accDao.getSourceAccount(10);
		//Account target = payeeDao.getPayeeDetails(20);
		
		//FundTransferDAO transDao;
		//acc 50000   -> 15000 -> 35000
		//targ 5000 + 15000 = 20000
		
		//transDao.trasfer(acc,target,amt);
		
		
	}

}
